package com.bi.springbootinit.mapper;

import com.bi.springbootinit.model.entity.Chart;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author legion
* @description 针对表【chart(图标信息表)】的数据库操作Mapper
* @createDate 2024-04-03 15:13:44
* @Entity com.bi.springbootinit.model.entity.Chart
*/
public interface ChartMapper extends BaseMapper<Chart> {

}




